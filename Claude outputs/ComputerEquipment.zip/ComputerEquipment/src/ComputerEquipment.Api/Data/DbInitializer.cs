using ComputerEquipment.Api.Domain;
using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace ComputerEquipment.Api.Data;

/// <summary>Применяет миграции и заполняет словарь типов и демо-данные, если таблицы пустые.</summary>
public static class DbInitializer
{
    private const long SeedLockKey = 7_100_002;
    private const int MaxAttempts = 10;

    private static readonly string[] DefaultTypes =
    [
        "Системный блок",
        "Ноутбук",
        "Монитор",
        "Принтер",
        "Сетевое оборудование",
    ];

    private static readonly (string Number, string Type, string Name, int Room)[] DefaultItems =
    [
        ("PC0001", "Системный блок", "Dell OptiPlex 7010", 101),
        ("PC0002", "Системный блок", "HP ProDesk 400 G9", 102),
        ("NB0001", "Ноутбук", "Lenovo ThinkPad T14 Gen 4", 205),
        ("NB0002", "Ноутбук", "ASUS ExpertBook B1", 207),
        ("MN0001", "Монитор", "Samsung S24C310", 101),
        ("MN0002", "Монитор", "LG 27UL500-W", 310),
        ("PR0001", "Принтер", "HP LaserJet Pro M404dn", 115),
        ("PR0002", "Принтер", "Canon i-SENSYS MF445dw", 220),
        ("NW0001", "Сетевое оборудование", "Cisco Catalyst 2960-X", 1),
        ("NW0002", "Сетевое оборудование", "MikroTik hAP ax3", 412),
    ];

    public static async Task InitializeAsync(IServiceProvider services, CancellationToken ct = default)
    {
        await using var scope = services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var logger = scope.ServiceProvider.GetRequiredService<ILoggerFactory>().CreateLogger(nameof(DbInitializer));

        await MigrateWithRetryAsync(db, logger, ct);

        // Блокировка защищает от двойного заполнения, если одновременно стартуют несколько экземпляров сервера.
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        await db.Database.ExecuteSqlAsync($"SELECT pg_advisory_xact_lock({SeedLockKey})", ct);

        if (!await db.EquipmentTypes.AnyAsync(ct))
        {
            db.EquipmentTypes.AddRange(DefaultTypes.Select(name => new EquipmentType { Name = name }));
            await db.SaveChangesAsync(ct);
            logger.LogInformation("Словарь типов техники заполнен: {Count} позиций", DefaultTypes.Length);
        }

        if (!await db.EquipmentItems.AnyAsync(ct))
        {
            var typeIds = await db.EquipmentTypes.ToDictionaryAsync(t => t.Name, t => t.Id, ct);
            var items = DefaultItems
                .Where(i => typeIds.ContainsKey(i.Type))
                .Select(i => new EquipmentItem
                {
                    InventoryNumber = i.Number,
                    Name = i.Name,
                    TypeId = typeIds[i.Type],
                    Room = i.Room,
                })
                .ToList();

            db.EquipmentItems.AddRange(items);
            await db.SaveChangesAsync(ct);
            logger.LogInformation("Добавлены демо-записи техники: {Count}", items.Count);
        }

        await tx.CommitAsync(ct);
    }

    private static async Task MigrateWithRetryAsync(AppDbContext db, ILogger logger, CancellationToken ct)
    {
        for (var attempt = 1; ; attempt++)
        {
            try
            {
                // Создает БД, если ее нет, и применяет все неприменённые миграции из Data/Migrations.
                // EF Core сам берет блокировку, поэтому параллельный старт нескольких экземпляров безопасен.
                await db.Database.MigrateAsync(ct);
                return;
            }
            catch (NpgsqlException ex) when (attempt < MaxAttempts)
            {
                logger.LogWarning("PostgreSQL недоступен (попытка {Attempt}/{Max}): {Message}", attempt, MaxAttempts, ex.Message);
                await Task.Delay(TimeSpan.FromSeconds(2), ct);
            }
        }
    }
}
