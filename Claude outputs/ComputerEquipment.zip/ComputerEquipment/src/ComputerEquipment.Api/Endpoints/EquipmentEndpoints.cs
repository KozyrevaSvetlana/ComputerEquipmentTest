using System.Linq.Expressions;
using System.Text.Json;
using ComputerEquipment.Api.Contracts;
using ComputerEquipment.Api.Data;
using ComputerEquipment.Api.Domain;
using ComputerEquipment.Api.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace ComputerEquipment.Api.Endpoints;

public static class EquipmentEndpoints
{
    /// <summary>Ключ advisory-блокировки: все вставки выполняются по очереди, чтобы лимит записей не превысили параллельные запросы.</summary>
    private const long CreateLockKey = 7_100_001;
    private const int DefaultPageSize = 20;
    private const int MaxPageSize = 100;

    private static readonly JsonSerializerOptions SortJsonOptions = new(JsonSerializerDefaults.Web);

    private static readonly Expression<Func<EquipmentItem, EquipmentDto>> ToDto = e =>
        new EquipmentDto(e.Id, e.InventoryNumber, e.Name, e.TypeId, e.Type.Name, e.Room, e.Version);

    public static IEndpointRouteBuilder MapEquipmentEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/equipment");

        group.MapGet("/", GetPage);
        group.MapGet("/{id:int}", GetById);
        group.MapPost("/", Create);
        group.MapPut("/{id:int}", Update);
        group.MapDelete("/{id:int}", Delete);

        return app;
    }

    /// <summary>
    /// Страница списка. Параметры совпадают с тем, что отправляет DevExtreme DataGrid:
    /// skip, take, sort=[{"selector":"name","desc":false}]. Дополнительно: typeId и search.
    /// </summary>
    private static async Task<IResult> GetPage(
        int? skip, int? take, string? sort, int? typeId, string? search,
        AppDbContext db, CancellationToken ct)
    {
        List<SortItem> sortItems;
        try
        {
            sortItems = string.IsNullOrWhiteSpace(sort)
                ? []
                : JsonSerializer.Deserialize<List<SortItem>>(sort, SortJsonOptions) ?? [];
        }
        catch (JsonException)
        {
            return Problems.BadRequest("Параметр sort должен быть JSON-массивом вида [{\"selector\":\"name\",\"desc\":false}].");
        }

        IQueryable<EquipmentItem> query = db.EquipmentItems.AsNoTracking();

        if (typeId is int t)
            query = query.Where(e => e.TypeId == t);

        if (!string.IsNullOrWhiteSpace(search))
        {
            var pattern = $"%{EscapeLike(search.Trim())}%";
            query = query.Where(e => EF.Functions.ILike(e.InventoryNumber, pattern) || EF.Functions.ILike(e.Name, pattern));
        }

        IOrderedQueryable<EquipmentItem>? ordered = null;
        foreach (var s in sortItems)
        {
            ordered = s.Selector switch
            {
                "inventoryNumber" => ApplyOrder(query, ordered, e => e.InventoryNumber, s.Desc),
                "typeName" => ApplyOrder(query, ordered, e => e.Type.Name, s.Desc),
                "name" => ApplyOrder(query, ordered, e => e.Name, s.Desc),
                "room" => ApplyOrder(query, ordered, e => e.Room, s.Desc),
                _ => null,
            };

            if (ordered is null)
                return Problems.BadRequest($"Сортировка по полю «{s.Selector}» не поддерживается.");
        }

        // Id в конце делает порядок стабильным: при одинаковых значениях строки не «прыгают» между страницами.
        var sorted = (ordered ?? query.OrderBy(e => e.InventoryNumber)).ThenBy(e => e.Id);

        var totalCount = await query.CountAsync(ct);
        var data = await sorted
            .Skip(Math.Max(skip ?? 0, 0))
            .Take(Math.Clamp(take ?? DefaultPageSize, 1, MaxPageSize))
            .Select(ToDto)
            .ToListAsync(ct);

        return Results.Ok(new PagedResult<EquipmentDto>(data, totalCount));
    }

    private static async Task<IResult> GetById(int id, AppDbContext db, CancellationToken ct)
    {
        var dto = await FindDto(db, id, ct);
        return dto is null ? Problems.NotFound($"Запись с id={id} не найдена.") : Results.Ok(dto);
    }

    private static async Task<IResult> Create(
        EquipmentRequest request, AppDbContext db, IOptions<EquipmentOptions> options, CancellationToken ct)
    {
        var input = EquipmentRules.Normalize(request);
        var errors = EquipmentRules.Validate(input, requireVersion: false);
        if (errors.Count > 0)
            return Results.ValidationProblem(errors);

        if (!await db.EquipmentTypes.AnyAsync(x => x.Id == input.TypeId, ct))
            return TypeNotFound();

        await using var tx = await db.Database.BeginTransactionAsync(ct);
        await db.Database.ExecuteSqlAsync($"SELECT pg_advisory_xact_lock({CreateLockKey})", ct);

        var limit = options.Value.MaxRecords;
        if (await db.EquipmentItems.CountAsync(ct) >= limit)
            return Problems.Conflict("Достигнут лимит записей", $"В базе уже {limit} записей — это максимум.", "limit");

        var entity = new EquipmentItem
        {
            InventoryNumber = input.InventoryNumber!,
            Name = input.Name!,
            TypeId = input.TypeId!.Value,
            Room = input.Room!.Value,
        };
        db.EquipmentItems.Add(entity);

        try
        {
            await db.SaveChangesAsync(ct);
            await tx.CommitAsync(ct);
        }
        catch (DbUpdateException ex) when (ex.IsUniqueViolation(AppDbContext.InventoryNumberIndex))
        {
            // Проверку «есть ли такой номер» не делаем заранее: между проверкой и вставкой
            // другой пользователь мог успеть сохранить тот же номер. Решает уникальный индекс.
            return DuplicateNumber(entity.InventoryNumber);
        }

        var dto = await FindDto(db, entity.Id, ct);
        return Results.Created($"/api/equipment/{entity.Id}", dto);
    }

    private static async Task<IResult> Update(int id, EquipmentRequest request, AppDbContext db, CancellationToken ct)
    {
        var input = EquipmentRules.Normalize(request);
        var errors = EquipmentRules.Validate(input, requireVersion: true);
        if (errors.Count > 0)
            return Results.ValidationProblem(errors);

        var entity = await db.EquipmentItems.FirstOrDefaultAsync(e => e.Id == id, ct);
        if (entity is null)
            return Problems.NotFound($"Запись с id={id} не найдена. Возможно, ее удалил другой пользователь.");

        if (!await db.EquipmentTypes.AnyAsync(x => x.Id == input.TypeId, ct))
            return TypeNotFound();

        // Версия, которую видел пользователь при открытии диалога. Если запись с тех пор изменили,
        // UPDATE ... WHERE xmin = @version не затронет строк и EF выбросит DbUpdateConcurrencyException.
        db.Entry(entity).Property(e => e.Version).OriginalValue = input.Version!.Value;

        entity.InventoryNumber = input.InventoryNumber!;
        entity.Name = input.Name!;
        entity.TypeId = input.TypeId!.Value;
        entity.Room = input.Room!.Value;

        try
        {
            await db.SaveChangesAsync(ct);
        }
        catch (DbUpdateConcurrencyException)
        {
            return Problems.Conflict(
                "Запись изменена другим пользователем",
                "Пока вы редактировали карточку, ее изменили или удалили. Откройте запись заново и повторите изменения.",
                "concurrency");
        }
        catch (DbUpdateException ex) when (ex.IsUniqueViolation(AppDbContext.InventoryNumberIndex))
        {
            return DuplicateNumber(entity.InventoryNumber);
        }

        return Results.Ok(await FindDto(db, id, ct));
    }

    private static async Task<IResult> Delete(int id, AppDbContext db, CancellationToken ct)
    {
        var deleted = await db.EquipmentItems.Where(e => e.Id == id).ExecuteDeleteAsync(ct);
        return deleted == 0 ? Problems.NotFound($"Запись с id={id} не найдена.") : Results.NoContent();
    }

    private static Task<EquipmentDto?> FindDto(AppDbContext db, int id, CancellationToken ct) =>
        db.EquipmentItems.AsNoTracking().Where(e => e.Id == id).Select(ToDto).FirstOrDefaultAsync(ct);

    private static IOrderedQueryable<EquipmentItem> ApplyOrder<TKey>(
        IQueryable<EquipmentItem> source,
        IOrderedQueryable<EquipmentItem>? ordered,
        Expression<Func<EquipmentItem, TKey>> key,
        bool desc)
    {
        if (ordered is null)
            return desc ? source.OrderByDescending(key) : source.OrderBy(key);

        return desc ? ordered.ThenByDescending(key) : ordered.ThenBy(key);
    }

    private static string EscapeLike(string value) =>
        value.Replace("\\", "\\\\").Replace("%", "\\%").Replace("_", "\\_");

    private static IResult DuplicateNumber(string number) =>
        Problems.Conflict(
            "Учетный номер уже занят",
            $"Запись с учетным номером «{number}» уже есть в базе. Возможно, ее только что добавил другой пользователь.",
            "duplicate");

    private static IResult TypeNotFound() =>
        Results.ValidationProblem(new Dictionary<string, string[]>
        {
            ["typeId"] = ["Такого типа техники нет в словаре. Обновите страницу."],
        });
}
