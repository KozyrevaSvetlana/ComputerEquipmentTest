using ComputerEquipment.Api.Contracts;
using ComputerEquipment.Api.Data;
using ComputerEquipment.Api.Domain;
using ComputerEquipment.Api.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace ComputerEquipment.Api.Endpoints;

/// <summary>Каталог и словарь типов техники.</summary>
public static class CatalogEndpoints
{
    public static IEndpointRouteBuilder MapCatalogEndpoints(this IEndpointRouteBuilder app)
    {
        app.MapGet("/api/catalog", GetCatalog);

        var types = app.MapGroup("/api/equipment-types");
        types.MapGet("/", GetTypes);
        types.MapPost("/", CreateType);
        types.MapDelete("/{id:int}", DeleteType);

        return app;
    }

    private static async Task<IResult> GetCatalog(AppDbContext db, IOptions<EquipmentOptions> options, CancellationToken ct)
    {
        var types = await LoadTypes(db, ct);
        return Results.Ok(new CatalogDto(types.Sum(t => t.Count), options.Value.MaxRecords, types));
    }

    private static async Task<IResult> GetTypes(AppDbContext db, CancellationToken ct) =>
        Results.Ok(await LoadTypes(db, ct));

    private static async Task<IResult> CreateType(EquipmentTypeRequest request, AppDbContext db, CancellationToken ct)
    {
        var name = request.Name?.Trim() ?? string.Empty;
        var errors = EquipmentRules.ValidateTypeName(name);
        if (errors.Count > 0)
            return Results.ValidationProblem(errors);

        var entity = new EquipmentType { Name = name };
        db.EquipmentTypes.Add(entity);

        try
        {
            await db.SaveChangesAsync(ct);
        }
        catch (DbUpdateException ex) when (ex.IsUniqueViolation(AppDbContext.TypeNameIndex))
        {
            return Problems.Conflict("Тип уже существует", $"Тип «{name}» уже есть в словаре.", "duplicate");
        }

        return Results.Created($"/api/equipment-types/{entity.Id}", new EquipmentTypeDto(entity.Id, entity.Name, 0));
    }

    private static async Task<IResult> DeleteType(int id, AppDbContext db, CancellationToken ct)
    {
        try
        {
            var deleted = await db.EquipmentTypes.Where(t => t.Id == id).ExecuteDeleteAsync(ct);
            return deleted == 0 ? Problems.NotFound($"Тип с id={id} не найден.") : Results.NoContent();
        }
        catch (Exception ex) when (ex is DbUpdateException dbu && dbu.IsForeignKeyViolation()
                                   || ex is Npgsql.PostgresException { SqlState: Npgsql.PostgresErrorCodes.ForeignKeyViolation })
        {
            return Problems.Conflict("Тип используется", "Нельзя удалить тип, пока к нему относится техника.", "in-use");
        }
    }

    private static Task<List<EquipmentTypeDto>> LoadTypes(AppDbContext db, CancellationToken ct) =>
        db.EquipmentTypes
            .AsNoTracking()
            .OrderBy(t => t.Name)
            .Select(t => new EquipmentTypeDto(t.Id, t.Name, t.Items.Count))
            .ToListAsync(ct);
}
