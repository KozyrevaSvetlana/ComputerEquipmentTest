namespace ComputerEquipment.Api.Domain;

/// <summary>Тип техники — запись словаря.</summary>
public sealed class EquipmentType
{
    public int Id { get; set; }

    public string Name { get; set; } = string.Empty;

    public List<EquipmentItem> Items { get; set; } = [];
}
