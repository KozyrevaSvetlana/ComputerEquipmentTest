using System.Text.RegularExpressions;
using ComputerEquipment.Api.Contracts;

namespace ComputerEquipment.Api.Domain;

/// <summary>Правила предметной области: ограничения полей и валидация.</summary>
public static partial class EquipmentRules
{
    public const int InventoryNumberMaxLength = 32;
    public const int NameMaxLength = 256;
    public const int TypeNameMaxLength = 128;
    public const int RoomMin = 1;
    public const int RoomMax = 1000;

    [GeneratedRegex("^[0-9A-Za-z]{1,32}$")]
    private static partial Regex InventoryNumberRegex();

    /// <summary>
    /// Учетный номер приводится к верхнему регистру, чтобы «pc01» и «PC01» считались одним номером.
    /// </summary>
    public static EquipmentRequest Normalize(EquipmentRequest request) => request with
    {
        InventoryNumber = request.InventoryNumber?.Trim().ToUpperInvariant() ?? string.Empty,
        Name = request.Name?.Trim() ?? string.Empty,
    };

    public static Dictionary<string, string[]> Validate(EquipmentRequest r, bool requireVersion)
    {
        var errors = new Dictionary<string, string[]>();

        if (string.IsNullOrEmpty(r.InventoryNumber))
            errors["inventoryNumber"] = ["Укажите учетный номер."];
        else if (!InventoryNumberRegex().IsMatch(r.InventoryNumber))
            errors["inventoryNumber"] = [$"Только цифры и латинские буквы, не длиннее {InventoryNumberMaxLength} символов."];

        if (string.IsNullOrEmpty(r.Name))
            errors["name"] = ["Укажите наименование."];
        else if (r.Name.Length > NameMaxLength)
            errors["name"] = [$"Наименование не длиннее {NameMaxLength} символов."];

        if (r.TypeId is null or <= 0)
            errors["typeId"] = ["Выберите тип техники."];

        if (r.Room is null)
            errors["room"] = ["Укажите комнату размещения."];
        else if (r.Room is < RoomMin or > RoomMax)
            errors["room"] = [$"Комната — целое число от {RoomMin} до {RoomMax}."];

        if (requireVersion && r.Version is null)
            errors["version"] = ["Не передана версия записи."];

        return errors;
    }

    public static Dictionary<string, string[]> ValidateTypeName(string name)
    {
        var errors = new Dictionary<string, string[]>();
        if (string.IsNullOrEmpty(name))
            errors["name"] = ["Укажите название типа."];
        else if (name.Length > TypeNameMaxLength)
            errors["name"] = [$"Название типа не длиннее {TypeNameMaxLength} символов."];
        return errors;
    }
}
