namespace ComputerEquipment.Api.Domain;

/// <summary>Единица компьютерной техники.</summary>
public sealed class EquipmentItem
{
    public int Id { get; set; }

    /// <summary>Учетный номер: цифры и латинские буквы, до 32 символов, уникален.</summary>
    public string InventoryNumber { get; set; } = string.Empty;

    /// <summary>Наименование, до 256 символов.</summary>
    public string Name { get; set; } = string.Empty;

    public int TypeId { get; set; }

    public EquipmentType Type { get; set; } = null!;

    /// <summary>Комната размещения, от 1 до 1000.</summary>
    public int Room { get; set; }

    /// <summary>Версия строки (системный столбец PostgreSQL xmin) для оптимистичной блокировки.</summary>
    public uint Version { get; set; }
}
