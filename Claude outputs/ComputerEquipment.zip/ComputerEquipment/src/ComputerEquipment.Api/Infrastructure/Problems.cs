using Microsoft.EntityFrameworkCore;
using Npgsql;

namespace ComputerEquipment.Api.Infrastructure;

/// <summary>Единые ответы об ошибках в формате ProblemDetails (RFC 9457).</summary>
public static class Problems
{
    public static IResult Conflict(string title, string detail, string code) =>
        Results.Problem(
            statusCode: StatusCodes.Status409Conflict,
            title: title,
            detail: detail,
            extensions: new Dictionary<string, object?> { ["code"] = code });

    public static IResult NotFound(string detail) =>
        Results.Problem(statusCode: StatusCodes.Status404NotFound, title: "Не найдено", detail: detail);

    public static IResult BadRequest(string detail) =>
        Results.Problem(statusCode: StatusCodes.Status400BadRequest, title: "Некорректный запрос", detail: detail);

    public static bool IsUniqueViolation(this DbUpdateException ex, string constraintName) =>
        ex.InnerException is PostgresException { SqlState: PostgresErrorCodes.UniqueViolation } pg
        && pg.ConstraintName == constraintName;

    public static bool IsForeignKeyViolation(this DbUpdateException ex) =>
        ex.InnerException is PostgresException { SqlState: PostgresErrorCodes.ForeignKeyViolation };
}
