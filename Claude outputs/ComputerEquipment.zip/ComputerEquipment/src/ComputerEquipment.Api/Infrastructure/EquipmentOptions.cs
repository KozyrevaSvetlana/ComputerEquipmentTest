namespace ComputerEquipment.Api.Infrastructure;

public sealed class EquipmentOptions
{
    public const string Section = "Equipment";

    /// <summary>Максимальное количество записей техники в БД.</summary>
    public int MaxRecords { get; set; } = 2000;
}
