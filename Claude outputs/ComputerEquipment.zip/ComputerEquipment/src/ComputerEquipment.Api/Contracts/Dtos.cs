namespace ComputerEquipment.Api.Contracts;

/// <summary>Тело запроса на создание/изменение техники. Version обязателен при изменении.</summary>
public sealed record EquipmentRequest(string? InventoryNumber, string? Name, int? TypeId, int? Room, uint? Version);

public sealed record EquipmentDto(int Id, string InventoryNumber, string Name, int TypeId, string TypeName, int Room, uint Version);

/// <summary>Страница данных в формате, который ожидает DevExtreme CustomStore.</summary>
public sealed record PagedResult<T>(IReadOnlyList<T> Data, int TotalCount);

public sealed record EquipmentTypeRequest(string? Name);

public sealed record EquipmentTypeDto(int Id, string Name, int Count);

/// <summary>Каталог: типы техники с количеством единиц, общее число записей и лимит.</summary>
public sealed record CatalogDto(int Total, int Limit, IReadOnlyList<EquipmentTypeDto> Types);

/// <summary>Элемент сортировки DevExtreme: { "selector": "name", "desc": true }.</summary>
public sealed record SortItem(string? Selector, bool Desc);
