using ComputerEquipment.Api.Data;
using ComputerEquipment.Api.Endpoints;
using ComputerEquipment.Api.Infrastructure;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("Default")));

builder.Services.Configure<EquipmentOptions>(builder.Configuration.GetSection(EquipmentOptions.Section));
builder.Services.AddProblemDetails();

var app = builder.Build();

app.UseExceptionHandler();
app.UseStatusCodePages();

await DbInitializer.InitializeAsync(app.Services, app.Lifetime.ApplicationStopping);

// Тонкий клиент (DevExtreme) раздается тем же сервером из wwwroot — один запуск, без CORS.
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapCatalogEndpoints();
app.MapEquipmentEndpoints();

app.Run();
